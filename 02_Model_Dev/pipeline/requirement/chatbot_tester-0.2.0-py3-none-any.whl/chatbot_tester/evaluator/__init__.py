__version__ = "0.0.1"

"""Placeholder package for Chatbot Evaluator.

실제 평가 로직은 추후 추가되며, 현재는 패키지 네임스페이스만 예약한다.
"""
